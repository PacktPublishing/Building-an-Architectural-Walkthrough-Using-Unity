﻿using UnityEngine;
using System.Collections;

public class rotateObject : MonoBehaviour {

	public GameObject target;

	void OnTriggerEnter(Collider other){
		target.transform.Rotate(0,90,0);
	}

	void OnTriggerExit(Collider other){
		target.transform.Rotate(0,-90,0);
	}
}
