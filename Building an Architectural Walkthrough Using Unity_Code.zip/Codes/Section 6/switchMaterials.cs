﻿using UnityEngine;
using System.Collections;

public class switchMaterials : MonoBehaviour {

	public Material[] materials;
	private int index;

	// Use this for initialization
	void Start () {
		index = 0;
	
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyUp(KeyCode.M)){
			this.renderer.material = materials[index];
			index = (index + 1) % materials.Length;
		}
	}

	void OnGUI(){
		if (GUI.Button(new Rect(10,10,120,20), "Switch Material")){
			this.renderer.material = materials[index];
			index = (index + 1) % materials.Length;
		}
	}
}
