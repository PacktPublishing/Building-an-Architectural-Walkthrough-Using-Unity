﻿using UnityEngine;
using System.Collections;

public class resetPlayer : MonoBehaviour {

	private GameObject player;
	private Vector3 pos;
	private Quaternion rot;

	public GameObject customSpawnPoint;

	// Use this for initialization
	void Start () {
		// find player
		player = GameObject.FindGameObjectWithTag("Player");
		// store transform
		pos = player.transform.position;
		rot = player.transform.localRotation;
	}
	
	void OnTriggerEnter(Collider other){
		if (other.gameObject.CompareTag("Player")){
			if (customSpawnPoint != null){
				player.transform.position = customSpawnPoint.transform.position;
				player.transform.localRotation = customSpawnPoint.transform.localRotation;
			} else {
				player.transform.position = pos;
				player.transform.localRotation = rot;
			}
		}
	}
}