﻿using UnityEngine;
using System.Collections;

public class toggleObjects : MonoBehaviour {

	public GameObject[] objects;

	void OnGUI () {
		// display a Toggle for each object
		foreach(GameObject go in objects){
			bool active = GUILayout.Toggle(go.activeSelf, go.name);
			if (active != go.activeSelf)
				go.SetActive(active);
		}
	}
}
