﻿using UnityEngine;
using System.Collections;

public class pickObject : MonoBehaviour {

	public Color highLight;
	private GameObject hitObject;;

	void Update () {
		if (Input.GetMouseButton(0)){
			// prepare a Ray to be cast into a RaycastHit
			RaycastHit hit;
			// called from current mouse position
			Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
			
			// Did we hit anything?
			if (Physics.Raycast(ray, out hit, 20)) {
				// Some info that is collected:
				Vector3 orto = hit.normal;
				float dist = hit.distance;
				Collider colly = hit.collider;
				Debug.Log("Hit! Distance " + dist + " from : " + colly.name);
				hitObject = colly.gameObject;

			}
			else {
				hitObject = null;
			}
		}
	}

	void OnGUI(){
		if (hitObject != null){
			if (hitObject.GetComponent<objectData>() != null){
				objectData data =
					(objectData)hitObject.GetComponent<objectData>();

				float screenThird = Screen.width / 3;
				GUILayout.BeginArea(new Rect(screenThird, 10,
				                             screenThird, 240));
				GUILayout.Label(hitObject.name);
				GUILayout.Label(data.shortName);
				data.description = GUILayout.TextArea(
					data.description, GUILayout.MinHeight(80));
				GUILayout.Label(data.totalCost.ToString());
				GUILayout.EndArea();
			} else
				GUILayout.Label(hitObject.name);
		}
	}
}
