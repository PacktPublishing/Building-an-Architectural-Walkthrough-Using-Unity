﻿using UnityEngine;
using System.Collections;

public class objectData : MonoBehaviour {

	public string shortName;
	public string description;
	public float totalCost;

}
